# Insult Generator

This program is a random insult generator! Use it to create very silly and totally impractical insults. You can customize your insult's length and level of insultiness.

## Installation

Download these files in a folder named "Insult Generator" in your "Documents" folder. Sorry the installation method sucks :(

## Usage

I'm not going to explain the usage! It's totally self-explanatory when you start the program. If you can't figure it out, well, maybe you deserve to be called one of the generator's random insults.

## Quick Notes on "Mean" Level Insults

Unfortunately, I'm not great at being mean. I tried to really muster up some grouchiness for this program, but the phrases I came up with for the "Mean" level insults are a bit scarce and lackluster. Feel free to add some meaner phrases to your copy of the program, or send me some (theme-appropriate) phrase suggestions.

## License

If you are looking at the "License" section of this file seriously, like, with the genuine expectation of finding a license here... you're the silliest of geese. No, of course there's no license.

## Shakespeare

I have a mug that has Shakespearean insults listed on it. It's my favorite cup of all time. If you want to check out some of the insults that have inspired me throughout the years, head [here.](https://www.litcharts.com/blog/shakespeare/top-shakespeare-insults-of-all-time/)
